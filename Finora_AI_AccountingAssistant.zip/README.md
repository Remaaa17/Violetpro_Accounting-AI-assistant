# AI Accounting Assistant 🤖💰

A modern accounting system with an intelligent AI assistant powered by Google Gemini that can analyze your financial data and answer questions in natural language.

## Features ✨

- 📊 **Interactive Dashboard**: View total income, expenses, balance, and transaction count
- 📈 **Visual Analytics**: Charts and graphs for financial insights
- 💬 **AI Assistant**: Ask questions about your finances in natural language
- 🔍 **Smart Analysis**: AI reads and analyzes your accounting data
- 📱 **Responsive Design**: Works on desktop and mobile devices

## Tech Stack 🛠️

- **Frontend**: React 18 + Vite
- **Backend**: Supabase (PostgreSQL)
- **AI**: Google Gemini API
- **Charts**: Recharts
- **Icons**: Lucide React

## Setup Instructions 🚀

### 1. Install Dependencies

\`\`\`bash
npm install
\`\`\`

### 2. Configure Supabase

1. Create a new project at [supabase.com](https://supabase.com)
2. Go to SQL Editor and run the setup script from `supabase/schema.sql`
3. Copy your project URL and anon key

### 3. Configure Environment Variables

Create a \`.env\` file in the root directory:

\`\`\`env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_GEMINI_API_KEY=your_gemini_api_key
\`\`\`

### 4. Import Data to Supabase

1. Go to your Supabase project dashboard
2. Navigate to Table Editor > transactions
3. Click "Insert" > "Import data from CSV"
4. Upload the \`synthetic_journal_entries.csv\` file
5. Map the columns correctly

### 5. Get Gemini API Key

1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create a new API key
3. Add it to your \`.env\` file

### 6. Run the Application

\`\`\`bash
npm run dev
\`\`\`

The app will open at \`http://localhost:3000\`

## AI Assistant Questions Examples 💬

- "What are my total expenses?"
- "What is my current balance?"
- "How much income did I receive?"
- "Which category has the highest expenses?"
- "What are my largest expenses?"
- "Give me a short summary of my financial activity"
- "Show me expenses for rent"
- "What were my salaries expenses?"

## Project Structure 📁

\`\`\`
├── src/
│   ├── components/
│   │   ├── Dashboard.jsx
│   │   ├── TransactionList.jsx
│   │   ├── AIAssistant.jsx
│   │   └── StatCard.jsx
│   ├── services/
│   │   ├── supabase.js
│   │   └── gemini.js
│   ├── utils/
│   │   └── dataProcessor.js
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── supabase/
│   └── schema.sql
├── package.json
└── README.md
\`\`\`

## Security Notes 🔒

- Never commit your \`.env\` file
- API keys are stored as environment variables
- Use Supabase Row Level Security (RLS) for production
- The AI assistant only has read access to your data

## Presentation Date 📅

**Deadline**: October 27, 2026  
**Presentation**: 10:30 AM (5-10 minutes)

## License

MIT License - Feel free to use this for your internship presentation!
